/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1424119223")

  // add field
  collection.fields.addAt(1, new Field({
    "hidden": false,
    "id": "number2907652725",
    "max": null,
    "min": null,
    "name": "Lat",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(2, new Field({
    "hidden": false,
    "id": "number3467548289",
    "max": null,
    "min": null,
    "name": "Lon",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(3, new Field({
    "hidden": false,
    "id": "number1069506978",
    "max": null,
    "min": null,
    "name": "Temperatura",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1424119223")

  // remove field
  collection.fields.removeById("number2907652725")

  // remove field
  collection.fields.removeById("number3467548289")

  // remove field
  collection.fields.removeById("number1069506978")

  return app.save(collection)
})
